import { catchError } from 'rxjs/operators';
import { AdminService } from './../admin.service';
import { Show } from './../Show';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-shows-for-movie',
  templateUrl: './shows-for-movie.component.html',
  styleUrls: ['./shows-for-movie.component.css']
})
export class ShowsForMovieComponent implements OnInit {
  show: Show[];
  showObj : Show;
  viewReport = new FormGroup({
    movieId: new FormControl('', Validators.required)
  })
  constructor(private adminService: AdminService, private router: Router) { }

  ngOnInit(): void {
    this.adminService.getAllShows().subscribe((show) => {
      console.log(show);
     });
     document.getElementById('showTable').style.display = "none";
  }

  viewReports() {
    let movieId = this.viewReport.get('movieId').value;
    this.adminService.getShowByMovieId(movieId).pipe(catchError((error: HttpErrorResponse) => {
      this.router.navigate(["show-error", error.error]);
      return throwError(error.error)
    })).subscribe(data => {
      console.log("true");
     this.show = data;
    });
    // for (let i = 0; i < this.show.length; i++) {
    //   if (this.show[i].movieId == movieId) {
    //     console.log("true");
    //     this.showObj = this.show[i];
    //     break;
    //   }
    //}
    document.getElementById("showTable").style.display = "block";
  }


}
