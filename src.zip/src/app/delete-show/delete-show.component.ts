import { catchError } from 'rxjs/operators';
import { AdminService } from './../admin.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-delete-show',
  templateUrl: './delete-show.component.html',
  styleUrls: ['./delete-show.component.css']
})
export class DeleteShowComponent implements OnInit {
  message: any;
  constructor(private adminService: AdminService, private router: Router) { }

  deleteShow = new FormGroup({
    showId: new FormControl('', Validators.required)
  })


  ngOnInit(): void {
    document.getElementById("message").style.display = "none";
  }

  deleteShowFunc() {
    let showId = this.deleteShow.get('showId').value;
    this.message = null;
    this.adminService.deleteShowFunc(showId).pipe(catchError((error: HttpErrorResponse) => {
      this.router.navigate(["show-error", error.error]);
      return throwError(error.error);
    })).subscribe(data => {
      console.log(data);
      this.message = "Show with id: " + showId + " is deleted successfully";
      document.getElementById("message").style.display = "block";
    })

  }
}