import { catchError } from 'rxjs/operators';
import { Movie } from './../Movie';
import { AdminService } from './../admin.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {
  flag1: any;
  message: any;
  welcomeMessage: any;
  movie: Movie[] = [];
  
  constructor(private adminSer: AdminService, private router: Router) { }
  movieDetails = new FormGroup({
    movieName: new FormControl('', Validators.required),
    movieGenre: new FormControl('', Validators.required),
    movieLanguage: new FormControl('', Validators.required),
    movieReleaseDate: new FormControl('', Validators.required),
  })


  ngOnInit(): void {
    document.getElementById("message").style.display = "none";
  
  }
    movieAdd() {
      
    let movieName = this.movieDetails.get('movieName').value;
    let movieGenre = this.movieDetails.get('movieGenre').value;
    let movieLanguage = this.movieDetails.get('movieLanguage').value;
    let movieReleaseDate = this.movieDetails.get('movieReleaseDate').value;
    
    let tempAdd: Movie = new Movie(null,movieName, movieGenre, movieLanguage, movieReleaseDate);
    this.adminSer.addMovie(tempAdd).pipe(catchError((error: HttpErrorResponse) => {
      this.router.navigate(["show-error", error.error]);
      return throwError(error.error)
    })).subscribe(data => {
      console.log(data);
      this.message = "Movie added successfully [ Movie Name: " + data.movieName + " ]";
      document.getElementById("message").style.display = "block"
    });
  }
  resetForm() {
    (document.getElementById("addBusForm") as HTMLFormElement).reset();
  }

}
