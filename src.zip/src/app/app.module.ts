// import { DialogBodyComponent } from './dialog-body/dialog-body.component';
// import { RemoveTheatreComponent } from './remove-theatre/remove-theatre.component';
// import { UpdateTheatreComponent } from './update-theatre/update-theatre.component';
// import { UpdateScreenComponent } from './update-screen/update-screen.component';
// import { ViewAllTheatreComponent } from './view-all-theatre/view-all-theatre.component';
// import { AddTheatreComponent } from './add-theatre/add-theatre.component';
import { AdminService } from './admin.service';
import { RouterModule } from '@angular/router';
import { ShowsForMovieComponent } from './shows-for-movie/shows-for-movie.component';
import { UpdateShowComponent } from './update-show/update-show.component';
import { FetchShowDetailsComponent } from './fetch-show-details/fetch-show-details.component';
import { DeleteShowComponent } from './delete-show/delete-show.component';
import { AddShowComponent } from './add-show/add-show.component';
//import { UpdateMovieComponent } from './update-movie/update-movie.component';
import { DeleteMovieComponent } from './delete-movie/delete-movie.component';
import { FetchDetailsComponent } from './fetch-details/fetch-details.component';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ShowErrorComponent } from './show-error/show-error.component';
// import { AddScreenComponent } from './add-screen/add-screen.component';
// import { ViewAllScreenComponent } from './view-all-screen/view-all-screen.component';

@NgModule({
  declarations: [
    AppComponent,
    AddMovieComponent,
    FetchDetailsComponent,
    DeleteMovieComponent,
    //UpdateMovieComponent,
    AddShowComponent,
    DeleteShowComponent,
    FetchShowDetailsComponent,
    UpdateShowComponent,
    ShowsForMovieComponent,
    ShowErrorComponent,
    // AddTheatreComponent,
    // AddScreenComponent,
    // ViewAllScreenComponent,
    // ViewAllTheatreComponent,
    // UpdateScreenComponent,
    // UpdateTheatreComponent,
    // RemoveTheatreComponent,
    // DialogBodyComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule,
    ReactiveFormsModule,
  ],
  providers: [AdminService],
  bootstrap: [AppComponent]
})
export class AppModule { }
