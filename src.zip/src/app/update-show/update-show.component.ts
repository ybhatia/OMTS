import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-show',
  templateUrl: './update-show.component.html',
  styleUrls: ['./update-show.component.css']
})
export class UpdateShowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
