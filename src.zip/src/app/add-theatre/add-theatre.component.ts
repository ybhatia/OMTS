import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Theatre } from '../Theatre';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { TheatreClass } from '../TheatreClass';
import { TheatreService } from '../theatre-service';

@Component({
  selector: 'app-add-theatre',
  templateUrl: './add-theatre.component.html',
  styleUrls: ['./add-theatre.component.css']
})
export class AddTheatreComponent implements OnInit {

 
  theatre: Theatre[]=[];
  message: string;
  constructor(private theatreSer:TheatreService,private router:Router) { }
  theatreDetails = new FormGroup({
    thetareId : new FormControl('', Validators.required),
    theatreName : new FormControl('',Validators.required),
    theatreCity : new FormControl('',Validators.required),
    managerName : new FormControl('',Validators.required),
    managerContact : new FormControl('',Validators.required),
    movieName1: new FormControl(''),
    movieName2: new FormControl(''),
    movieName3: new FormControl(''),
    movieName4: new FormControl(''),
    movieName5: new FormControl('')  
    
  })
 
    ngOnInit(): void 
    {
    
    }
  addTheatre()
  {
    
    let theatreId=this.theatreDetails.get('theatreId').value;
    let theatreName=this.theatreDetails.get('theatreName').value;
    let theatreCity=this.theatreDetails.get('theatreCity').value;
    let managerName=this.theatreDetails.get('managerName').value;
    let managerContact=this.theatreDetails.get('managerContact').value;
    let movieName1=this.theatreDetails.get('movieName1').value;
    let movieName2=this.theatreDetails.get('movieName2').value;
    let movieName3=this.theatreDetails.get('movieName3').value;
    let movieName4=this.theatreDetails.get('movieName4').value;
    let movieName5=this.theatreDetails.get('movieName5').value;
    let movieNames:any[]=[movieName1,movieName2,movieName3,movieName4,movieName5];
    let movieList:any[]=[];
    for(let i=0;i<5;i++)
    {
    movieList[i]=movieNames[i]
    }


    let tempTheatre:TheatreClass= new TheatreClass(theatreId,theatreName,theatreCity,movieList,managerName,managerContact);
    this.theatreSer.addTheatre(tempTheatre).subscribe(data=> {
      console.log(data);
      this.message="Theatre added successfully [ Theatre ID: "+tempTheatre.theatreId+" ]";
      document.getElementById("message").style.display="block"
    });    
    this.theatre[0]=tempTheatre;
  }
  

}

