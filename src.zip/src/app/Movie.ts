export class Movie {
    id: any;
    movieId : any;
    movieName: any;
    movieGenre: any;
    movieLanguage: any;
    movieReleaseDate: any;
    constructor(movieId, movieName, movieGenre, movieLanguage, movieReleaseDate) {
        this.movieId = movieId;
        this.movieName = movieName;
        this.movieGenre = movieGenre;
        this.movieLanguage = movieLanguage;
        this.movieReleaseDate = movieReleaseDate;
    }
}