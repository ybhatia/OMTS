import { Movie } from './../Movie';
import { catchError } from 'rxjs/operators';
import { AdminService } from './../admin.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-delete-movie',
  templateUrl: './delete-movie.component.html',
  styleUrls: ['./delete-movie.component.css']
})
export class DeleteMovieComponent implements OnInit {
  message: any;
  movie: Movie[];
  msg : any;

  constructor(private adminService: AdminService, private router: Router) { }
  deleteMovie = new FormGroup({
    movieId: new FormControl('', Validators.required)
  })

  ngOnInit(): void {
    // this.adminService.getAllMovies().subscribe((data) => {
    //   this.movie = data;
   // })
    document.getElementById("message").style.display = "none";
  }
  deleteMovieFunc(){
    let movieId = this.deleteMovie.get('movieId').value;
    this.message = null;
    this.adminService.deleteMovie(movieId).pipe(catchError((error: HttpErrorResponse) => {
      this.msg = error.error;
      console.log(this.msg);
      this.router.navigate(["show-error", this.msg]);
      return throwError(error.error);
      
    })).subscribe(data => {
      console.log(data);
      this.message = "Movie with id: " + movieId + " is deleted successfully";
      document.getElementById("message").style.display = "block";
    })
  }
  }


