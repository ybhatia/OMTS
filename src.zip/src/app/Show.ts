export class Show {
    id: any;
    showId : any
    movieId : any;
    noOfSeats : any;
    showStartTime : any;
    showEndTime : any;
    constructor(showId, movieId, noOfSeats, showStartTime, showEndTime) {
        this.showId = showId;
        this.movieId = movieId;
        this.noOfSeats = noOfSeats;
        this.showStartTime = showStartTime;
        this.showEndTime = showEndTime;
    }
}