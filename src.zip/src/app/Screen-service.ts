import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ScreenClass } from './ScreenClass';
@Injectable({
    providedIn: 'root'
  })
export class ScreenService{
  public screenId:any;
    constructor(private httpClient:HttpClient){}
    httpOptions={
        headers:new HttpHeaders({
          'Content-Type':'application/json'
        })
}
getScreens():Observable<ScreenClass[]>
{
  return this.httpClient.get<ScreenClass[]>('http://localhost:9092/screen/getAllScreens',this.httpOptions)
}
addScreen(screen:ScreenClass):Observable<ScreenClass>
{
  return this.httpClient.post<ScreenClass>('http://localhost:9092/screen/new',JSON.stringify(screen),this.httpOptions)
}
deleteScreen(id:any):Observable<number[]>
{
  return this.httpClient.delete<number[]>('http://localhost:9092/screen/delete/id='+id,this.httpOptions)
}
editScreen(screen:ScreenClass):Observable<ScreenClass>
{
  return this.httpClient.put<ScreenClass>('http://localhost:9092/screen/update',JSON.stringify(screen),this.httpOptions)
}

}