import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-screen',
  templateUrl: './update-screen.component.html',
  styleUrls: ['./update-screen.component.css']
})
export class UpdateScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
