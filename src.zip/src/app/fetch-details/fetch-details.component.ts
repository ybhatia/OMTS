import { AdminService } from './../admin.service';
import { Movie } from './../Movie';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-fetch-details',
  templateUrl: './fetch-details.component.html',
  styleUrls: ['./fetch-details.component.css']
})
export class FetchDetailsComponent implements OnInit {
  movie: Movie;
  movieArr: Movie[];
  movieLanguageArr: Movie[];
  movieObj: Movie;
  viewReport = new FormGroup({
    movieId: new FormControl('', Validators.required)
  })
  viewReportsByGenre = new FormGroup({
    movieGenre: new FormControl('', Validators.required)
  })
  viewReportsByLanguage = new FormGroup({
    movieLanguage: new FormControl('', Validators.required)
  })
  viewReportsByName = new FormGroup({
    movieName: new FormControl('', Validators.required)
  })

  constructor(private adminService: AdminService, private router: Router) { }

  ngOnInit(): void {
    this.adminService.getAllMovies().subscribe((movie) => {
      console.log(movie);
    });
    document.getElementById('movieTable').style.display = "none";
    document.getElementById('movieTableForGenre').style.display = "none";
    document.getElementById('movieTableForLanguage').style.display = "none";
    document.getElementById('movieTableForName').style.display = "none";
  }

  viewReports() {    
      let movieId = this.viewReport.get('movieId').value;
    this.adminService.getMovieById(movieId).pipe(catchError((error: HttpErrorResponse) => {
      this.router.navigate(["show-error", error.error]);
      return throwError(error.error)
    })).subscribe(data => {
      console.log("true");
      this.movie = data;
    });
    document.getElementById("movieTable").style.display = "block";
  }

  viewReportByGenre() {
    console.log("Genre")
    let movieGenre = this.viewReportsByGenre.get('movieGenre').value;
    this.movieArr = [];
    this.adminService.getMovieByGenre(movieGenre).pipe(catchError((error: HttpErrorResponse) => {
      this.router.navigate(["show-error", error.error.message]);
      return throwError(error.error.message)
    })).subscribe(data => {
      this.movieArr = data;
    });
    document.getElementById("movieTableForGenre").style.display = "block";
  }

  viewReportByLanguage() {
    let movieLanguage = this.viewReportsByLanguage.get('movieLanguage').value;
    this.movieLanguageArr = [];
    this.adminService.getMovieByLanguage(movieLanguage).pipe(catchError((error: HttpErrorResponse) => {
      this.router.navigate(["show-error", error.error.message]);
      return throwError(error.error.message)
    })).subscribe(data => {
      this.movieLanguageArr = data;
    });
    document.getElementById("movieTableForLanguage").style.display = "block";
  }

  viewReportByName() {
    let movieName = this.viewReportsByName.get('movieName').value;
    this.adminService.getMovieByName(movieName).pipe(catchError((error: HttpErrorResponse) => {
      this.router.navigate(["show-error", error.error]);
      return throwError(error.error)
    })).subscribe(data => {
      console.log("true");
     this.movieObj = data;
    });
    document.getElementById("movieTableForName").style.display = "block";
  }
}
