import { catchError } from 'rxjs/operators';
import { Movie } from './../Movie';
import { AdminService } from './../admin.service';
import { Show } from './../Show';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-fetch-show-details',
  templateUrl: './fetch-show-details.component.html',
  styleUrls: ['./fetch-show-details.component.css']
})
export class FetchShowDetailsComponent implements OnInit {
  show: Show;
  movie : Movie[];
  movieObj : Movie;
  viewReport = new FormGroup({
    showId: new FormControl('', Validators.required)
  })

  constructor(private adminService: AdminService, private router: Router) { }

  ngOnInit(): void {
    this.adminService.getAllShows().subscribe((show) => {
      console.log(show);
     });
     this.adminService.getAllMovies().subscribe((data) => {
      //console.log(movie);
      this.movie = data;
     });
     document.getElementById('showTable').style.display = "none";
  }

  viewReports() {
    let showId = this.viewReport.get('showId').value;
    this.adminService.getShowById(showId).pipe(catchError((error: HttpErrorResponse) => {
      this.router.navigate(["show-error", error.error]);
      return throwError(error.error)
    })).subscribe(data => {
      console.log("true");
     this.show = data;
    });
    for (let i = 0; i < this.movie.length; i++) {
      if (this.movie[i].movieId == this.show.movieId) {
        console.log("true");
        this.movieObj = this.movie[i];
        break;
      }
    }
    // this.adminService.getMovieById(this.show.movieId).subscribe(data => {
    //   console.log("movie");
    //   this.movieObj = this.show.movieId;

    // })
    document.getElementById("showTable").style.display = "block";
  }
}
