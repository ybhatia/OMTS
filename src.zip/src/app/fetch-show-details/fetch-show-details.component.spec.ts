import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FetchShowDetailsComponent } from './fetch-show-details.component';

describe('FetchShowDetailsComponent', () => {
  let component: FetchShowDetailsComponent;
  let fixture: ComponentFixture<FetchShowDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FetchShowDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FetchShowDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
