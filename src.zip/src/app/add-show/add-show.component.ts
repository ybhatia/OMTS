import { catchError } from 'rxjs/operators';
import { AdminService } from './../admin.service';
import { Show } from './../Show';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-add-show',
  templateUrl: './add-show.component.html',
  styleUrls: ['./add-show.component.css']
})
export class AddShowComponent implements OnInit {
  flag1: any;
  message: any;
  welcomeMessage: any;
  show: Show[] = [];
  constructor(private adminSer: AdminService, private router: Router) { }
  showDetails = new FormGroup({
    movieId: new FormControl('', Validators.required),
    noOfSeats: new FormControl('', Validators.required),
    showStartTime: new FormControl('', Validators.required),
    showEndTime: new FormControl('', Validators.required),
  })

  ngOnInit(): void {
    document.getElementById("message").style.display = "none";
  }

  showAdd() {
      
    let movieId = this.showDetails.get('movieId').value;
    let noOfSeats = this.showDetails.get('noOfSeats').value;
    let showStartTime = this.showDetails.get('showStartTime').value;
    let showEndTime = this.showDetails.get('showEndTime').value;
    
    let tempAdd: Show = new Show(null,movieId, noOfSeats, showStartTime, showEndTime);
    this.adminSer.addShow(tempAdd).pipe(catchError((error: HttpErrorResponse) => {
      this.router.navigate(["show-error", error.error]);
      return throwError(error.error)
    })).subscribe(data => {
      console.log(data);
      this.message = "Show added successfully for [ Movie Id: " + movieId + " ]";
      document.getElementById("message").style.display = "block"
    });
  }
  resetForm() {
    (document.getElementById("addBusForm") as HTMLFormElement).reset();
  }

}
