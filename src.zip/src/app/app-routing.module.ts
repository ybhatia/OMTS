import { ShowComponent } from './show/show.component';
import { MovieComponent } from './movie/movie.component';
import { UpdateScreenComponent } from './update-screen/update-screen.component';
import { AddTheatreComponent } from './add-theatre/add-theatre.component';
import { UpdateTheatreComponent } from './update-theatre/update-theatre.component';
import { RemoveTheatreComponent } from './remove-theatre/remove-theatre.component';
import { ViewAllTheatreComponent } from './view-all-theatre/view-all-theatre.component';
import { ShowErrorComponent } from './show-error/show-error.component';
import { DeleteMovieComponent } from './delete-movie/delete-movie.component';
import { ShowsForMovieComponent } from './shows-for-movie/shows-for-movie.component';
import { AddShowComponent } from './add-show/add-show.component';
import { DeleteShowComponent } from './delete-show/delete-show.component';
//import { UpdateMovieComponent } from './update-movie/update-movie.component';
import { FetchShowDetailsComponent } from './fetch-show-details/fetch-show-details.component';
import { FetchDetailsComponent } from './fetch-details/fetch-details.component';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddScreenComponent } from './add-screen/add-screen.component';
import { ViewAllScreenComponent } from './view-all-screen/view-all-screen.component';


const routes: Routes = [
  { path: '', redirectTo: 'view-all-theatre', pathMatch: 'full' },
  {
    path: 'movie', component: MovieComponent,
    children: [
      { path: '', redirectTo: 'add-movie', pathMatch: 'full' },
       { path: 'add-movie', component: AddMovieComponent},
      { path: 'delete-movie', component: DeleteMovieComponent },
      { path: 'fetch-details', component: FetchDetailsComponent }
    ]
  },
  // {path: 'update-movie', component: UpdateMovieComponent},
  {
    path: 'show', component: ShowComponent,
    children: [
      { path: '', redirectTo: 'add-show', pathMatch: 'full' },
     { path: 'add-show', component: AddShowComponent},
      { path: 'show-for-movie', component: ShowsForMovieComponent },
      { path: 'delete-show', component: DeleteShowComponent },
      { path: 'fetch-show-details', component: FetchShowDetailsComponent },
    ]
  },
  { path: "show-error/:errMsg", component: ShowErrorComponent },
  { path: 'view-all-theatre', component: ViewAllTheatreComponent },
  { path: 'remove-theatre', component: RemoveTheatreComponent },
  { path: 'update-theatre', component: UpdateTheatreComponent },
  { path: 'add-theatre', component: AddTheatreComponent },
  { path: 'view-all-screen', component: ViewAllScreenComponent },
  { path: 'update-screen', component: UpdateScreenComponent },
  { path: 'add-screen', component: AddScreenComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
