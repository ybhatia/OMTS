import { Component, OnInit } from '@angular/core';
import { TheatreClass } from '../TheatreClass';
import { TheatreService } from '../theatre-service';
import { Router } from '@angular/router';
import { DialogBodyComponent } from '../dialog-body/dialog-body.component';
import { UpdateTheatreComponent } from '../update-theatre/update-theatre.component';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';

@Component({
  selector: 'app-view-all-theatre',
  templateUrl: './view-all-theatre.component.html',
  styleUrls: ['./view-all-theatre.component.css']
})
export class ViewAllTheatreComponent implements OnInit {

  flag1: boolean = false;
  checkEmptyFlag: boolean;
  theatre: TheatreClass[];
  currentTheatre: TheatreClass[];
  message: any;
  constructor(private matDialog: MatDialog, private theatreSer: TheatreService, private router: Router) { }

  ngOnInit(): void {
    document.getElementById("theatreTable").style.display = "none";
    this.theatreSer.getTheatre().subscribe(data => this.theatre = data);
    console.log(this.theatre);
    this.currentTheatre = this.theatre;
    document.getElementById("theatreTable").style.display = "block";
  }
  openDialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.height = '680px';
    dialogConfig.width = '450px';
    const dialogRef = this.matDialog.open(DialogBodyComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(data => console.log(data));
  }
  openEditDialog(theatreId) {
    this.theatreSer.theatreId=theatreId;
    const editDialogConfig = new MatDialogConfig();
    editDialogConfig.disableClose = true;
    editDialogConfig.autoFocus = true;
    editDialogConfig.height = '680px';
    editDialogConfig.width = '450px';
    const editDialogRef = this.matDialog.open(UpdateTheatreComponent, editDialogConfig);
    editDialogRef.afterClosed().subscribe(data => console.log(data));
  }
  removeTheatre(theatreId) {
    let response = window.confirm("Are you sure you want to delete?");
    console.log(response);
    if (response == true) {
      for (let i = 0; i < this.theatre.length; i++) {
        if (this.theatre[i].theatreId == theatreId) {
          this.theatre.splice(i, 1);
          this.theatreSer.deleteTheatre(theatreId).subscribe(data => (console.log(data)));
          console.log("Theatre deleted");
          this.flag1 = true;
        }
      }
      window.location.reload();
      window.location.reload();
    }
  }




}
