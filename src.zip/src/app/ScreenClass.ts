export class ScreenClass {
    screenId:any;
    theatreId:any;
    screenName:any;
    rows:any;
    columns:any;

    constructor(screenId,theatreId,screenName,rows,columns){
        this.screenId=screenId;
        this.theatreId=theatreId;
        this.screenName=screenName;
        this.rows=rows;
        this.columns=columns;
    }

}