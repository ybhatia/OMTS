import { Show } from './Show';
import { Movie } from './Movie';
import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
  constructor(private httpClient: HttpClient) { }

  addMovie(movie: Movie): Observable<Movie> {
    return this.httpClient.post<Movie>("http://localhost:1111/movie/addmovie", JSON.stringify(movie), this.options);
  }

  addShow(show: Show): Observable<Show> {
    return this.httpClient.post<Show>("http://localhost:1112/show/addshow", JSON.stringify(show), this.options);
  }

  getMovieById(id : any): Observable<Movie> {
    return this.httpClient.get<Movie>("http://localhost:1111/movie/moviebyid/"+ id, this.options);
  }

  getShowById(id : any): Observable<Show> {
    return this.httpClient.get<Show>("http://localhost:1112/show/showbyid/"+ id, this.options);
  }

  getShowByMovieId(id : any): Observable<Show[]> {
    return this.httpClient.get<Show[]>("http://localhost:1112/show/showbymovieid/"+ id, this.options);
  }
 
  getAllMovies(): Observable<Movie[]> {
    return this.httpClient.get<Movie[]>("http://localhost:1111/movie/allmovies", this.options);
  }

  getAllShows(): Observable<Show[]> {
    return this.httpClient.get<Show[]>("http://localhost:1112/show/allshows", this.options);
  }

  getMovieByGenre(genre : any): Observable<Movie[]> {
    return this.httpClient.get<Movie[]>("http://localhost:1111/movie/moviebygenre/"+ genre, this.options);
  }

  getMovieByLanguage(language : any): Observable<Movie[]> {
    return this.httpClient.get<Movie[]>("http://localhost:1111/movie/moviebylanguage/"+ language, this.options);
  }

  getMovieByName(name : any): Observable<Movie> {
    return this.httpClient.get<Movie>("http://localhost:1111/movie/moviebyname/"+ name, this.options);
  }

  getMovieByReleaseDate(releaseDate : any): Observable<Movie[]> {
    return this.httpClient.get<Movie[]>("http://localhost:1111/movie/moviebyname/"+ releaseDate, this.options);
  }

  deleteMovie(id: any): Observable<Boolean> {
    return this.httpClient.delete<Boolean>("http://localhost:1111/movie/delete/" + id, this.options);
  }

  deleteShowFunc(id: any): Observable<Show> {
    return this.httpClient.delete<Show>("http://localhost:1112/show/delete/" + id, this.options);
  }
}
