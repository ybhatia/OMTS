import { Component, OnInit } from '@angular/core';
import { TheatreClass } from '../TheatreClass';
import { TheatreService } from '../theatre-service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-remove-theatre',
  templateUrl: './remove-theatre.component.html',
  styleUrls: ['./remove-theatre.component.css']
})
export class RemoveTheatreComponent implements OnInit {

  flag1:boolean;
   theatre:TheatreClass[];

  constructor(private theatreSer:TheatreService,private router:Router) { }
   deleteTheatre=new FormGroup({
   theatreId:new FormControl('',Validators.required)
 })
  ngOnInit(): void {
  }
  
  
  removeTheatre(theatreId) {
   
    let response=window.confirm("Are you sure you want to delete?");
    console.log(response);
    if(response==true){
    for (let i = 0; i < this.theatre.length; i++) {
      if (this.theatre[i].theatreId == theatreId) {
        this.theatre.splice(i, 1);
        this.theatreSer.deleteTheatre(theatreId).subscribe(data => (console.log(data)));
        console.log("Theatre deleted");
        this.flag1 = true;
      }
    }
    window.location.reload();
    window.location.reload();
    }
  }
}
  
